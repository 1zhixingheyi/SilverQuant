# CCPM全流程命令详细指南

## 文档说明

**官方信息源**: [CCPM GitHub仓库](https://github.com/automazeio/ccpm)
**验证日期**: 2025-01-19
**基于版本**: Main分支（最新版本）
**验证方法**: 基于官方命令定义文件和官方README.md

**内容来源**:
- 所有命令语法基于 `.claude/commands/pm/` 目录下的官方命令定义文件
- 工作流程基于官方README.md的系统架构和工作流程说明
- 参数和示例基于官方命令文件中的具体实现逻辑

---

## CCPM概述

CCPM是Claude Code项目管理系统，通过GitHub Issues和Git Worktrees实现并行AI代理开发。核心理念是**规范驱动开发**，确保每行代码都能追溯到明确的规范。

### 核心特性
- **5阶段工作流程**: Brainstorm → Document → Plan → Execute → Track
- **并行AI执行**: 多个Claude实例可同时工作在不同任务上
- **GitHub原生集成**: 使用Issues作为数据库，无需额外工具
- **Context保持**: 每个Epic维护独立上下文，避免信息丢失

---

## 完整工作流程概述

```
阶段1: 系统初始化 (/pm:init)
   ↓
阶段2: 创建PRD (/pm:prd-new feature-name)
   ↓
阶段3: PRD转技术方案 (/pm:prd-parse feature-name)
   ↓
阶段4: 分解并同步 (/pm:epic-oneshot feature-name)
   ↓
阶段5: 并行执行 (/pm:epic-start feature-name)
   ↓
阶段6: 状态跟踪 (/pm:status, /pm:epic-show)
```

---

## 第一阶段：系统初始化

### `/pm:init` - 初始化CCPM系统

**官方来源**: `.claude/commands/pm/init.md`

#### 命令语法
```bash
/pm:init
```

#### 功能说明
运行初始化脚本设置CCPM项目管理环境，包括：
- 安装GitHub CLI（如果需要）
- 认证GitHub账户
- 安装gh-sub-issue扩展（用于父子Issue关系）
- 创建必需目录结构
- 更新.gitignore文件

#### 前置条件
- 当前目录是Git仓库
- 有网络连接用于下载依赖
- 有GitHub账户访问权限

#### 执行过程
```bash
# 1. 执行初始化
/pm:init

# 系统会自动执行以下操作：
# - 运行 bash .claude/scripts/pm/init.sh
# - 安装和配置GitHub CLI
# - 设置认证
# - 创建目录结构

# 2. 验证初始化成功
/pm:help
```

#### 预期输出
```
✓ GitHub CLI installed and authenticated
✓ gh-sub-issue extension installed
✓ Project directories created
✓ .gitignore updated
✓ CCPM initialization complete
```

#### 创建的目录结构
```
.claude/
├── prds/              # 产品需求文档存放目录
├── epics/             # Epic和任务文件存放目录
├── context/           # 项目上下文文件
├── commands/pm/       # PM命令定义（已存在）
└── scripts/pm/        # PM脚本文件（已存在）
```

---

## 第二阶段：创建产品需求文档

### `/pm:prd-new` - 创建新的PRD

**官方来源**: `.claude/commands/pm/prd-new.md`

#### 命令语法
```bash
/pm:prd-new <feature_name>
```

#### 参数说明
- `feature_name`: 功能名称，必须使用kebab-case格式（小写字母、数字、连字符）

#### 功能说明
启动交互式头脑风暴会话，创建全面的产品需求文档。这是整个项目管理流程的起点。

#### 输入验证
```bash
# ✅ 正确的格式
/pm:prd-new user-authentication
/pm:prd-new blog-system
/pm:prd-new api-v2

# ❌ 错误的格式
/pm:prd-new UserAuthentication  # 包含大写字母
/pm:prd-new user_authentication # 包含下划线
/pm:prd-new "user auth"         # 包含空格
```

#### 完整示例：创建博客系统PRD

```bash
# 1. 启动PRD创建
/pm:prd-new blog-system

# 2. 系统会启动交互式会话，引导你完成以下章节：
```

**PRD文件结构**（基于官方模板）:
```yaml
---
name: blog-system
description: "个人博客系统，支持文章发布、评论和用户管理"
status: backlog
created: 2025-01-19T10:30:00Z
---

# Blog System - 产品需求文档

## Executive Summary（执行摘要）
构建一个现代化的个人博客平台，支持文章发布、分类管理、评论系统和基础用户管理功能。

## Problem Statement（问题陈述）
现有博客平台要么功能过于复杂，要么缺乏必要的自定义能力。需要一个简洁但功能完整的博客解决方案。

## User Stories（用户故事）
### 作为博主，我希望能够：
- 创建和发布文章
- 对文章进行分类和标签管理
- 管理评论和读者互动
- 查看访问统计

### 作为读者，我希望能够：
- 浏览和搜索文章
- 对文章进行评论
- 订阅感兴趣的分类

## Requirements（需求）

### 功能性需求
1. **文章管理**
   - 富文本编辑器支持
   - Markdown格式支持
   - 草稿保存功能
   - 文章分类和标签

2. **用户系统**
   - 用户注册和登录
   - 个人资料管理
   - 权限控制（管理员/普通用户）

3. **评论系统**
   - 嵌套评论支持
   - 评论审核机制
   - 反垃圾评论

### 非功能性需求
- 响应时间：页面加载<2秒
- 并发用户：支持1000+同时在线
- 安全性：HTTPS，SQL注入防护
- SEO友好：静态URL，meta标签

## Success Criteria（成功标准）
- [ ] 用户可以在5分钟内完成注册和发布第一篇文章
- [ ] 页面加载时间平均<2秒
- [ ] 评论系统无垃圾评论困扰
- [ ] 移动端用户体验良好

## Constraints & Assumptions（约束和假设）
- 使用现有技术栈（Python + React）
- 预算限制：2周开发时间
- 假设用户熟悉基本的博客概念

## Out of Scope（范围外）
- 多语言支持
- 高级SEO功能
- 社交媒体集成
- 付费订阅功能

## Dependencies（依赖关系）
- 数据库设计完成
- UI设计规范确定
- 域名和托管环境准备
```

#### 输出文件
```
.claude/prds/blog-system.md
```

### 列出PRD - `/pm:prd-list`

**官方来源**: `.claude/commands/pm/prd-list.md`

#### 命令格式与参数
```bash
/pm:prd-list
```

#### 功能说明
调用脚本 `bash .claude/scripts/pm/prd-list.sh`，显示所有PRD文件列表，完整输出不截断。

#### 核心特性
- **完整扫描**: 扫描`.claude/prds/`目录下所有PRD文件
- **状态分析**: 分析每个PRD的frontmatter和关联Epic
- **快速操作**: 为每个PRD提供相应的下一步操作建议
- **智能分类**: 按状态和优先级排序显示

#### 详细使用示例
```bash
# 列出所有PRD及其状态
/pm:prd-list
```

#### 预期输出格式
```
📋 PRD列表 (共4个)
┌─────────────────┬──────────────┬──────────────┬─────────────────┬──────────────┐
│ PRD名称         │ 状态         │ 最后修改     │ 关联Epic        │ 快速操作     │
├─────────────────┼──────────────┼──────────────┼─────────────────┼──────────────┤
│ user-auth       │ ✅ 已实施    │ 2024-01-15   │ epic-user-auth  │ /pm:epic-show│
│ data-storage    │ 🔄 开发中    │ 2024-01-14   │ epic-storage    │ /pm:status   │
│ api-gateway     │ 📋 待解析    │ 2024-01-13   │ -               │ /pm:prd-parse│
│ notification    │ ✏️ 草稿      │ 2024-01-12   │ -               │ /pm:prd-edit │
└─────────────────┴──────────────┴──────────────┴─────────────────┴──────────────┘

🎯 建议下一步:
- 完成 notification PRD 编写: /pm:prd-edit notification
- 解析 api-gateway PRD: /pm:prd-parse api-gateway
- 检查 data-storage 进度: /pm:epic-show data-storage
```

### 编辑PRD - `/pm:prd-edit`

**官方来源**: `.claude/commands/pm/prd-edit.md`

#### 命令格式与参数
```bash
/pm:prd-edit <feature_name>
```

#### 功能说明
编辑现有产品需求文档，支持章节级别的精确修改和版本控制。

#### 核心特性
- **交互式编辑**: 用户选择要编辑的特定章节
- **版本控制**: 保留原始创建日期，更新修改时间
- **Epic关联检查**: 检测PRD关联的Epic并提醒用户审查
- **格式保持**: 严格遵循frontmatter操作规则

#### 可编辑章节
- **Executive Summary** (执行摘要)
- **Problem Statement** (问题陈述)
- **User Stories** (用户故事)
- **Requirements** (功能/非功能需求)
- **Success Criteria** (成功标准)
- **Constraints & Assumptions** (约束和假设)
- **Out of Scope** (超出范围)
- **Dependencies** (依赖关系)

#### 详细使用示例
```bash
# 编辑博客系统PRD
/pm:prd-edit blog-system

# 系统会显示可编辑章节列表
# 用户选择章节进行编辑
# 自动检查关联Epic的影响
```

#### 交互式编辑流程
```
🔧 编辑PRD: blog-system

📋 可编辑章节:
1. Executive Summary (执行摘要)
2. Problem Statement (问题陈述)
3. User Stories (用户故事)
4. Requirements (需求)
5. Success Criteria (成功标准)
6. Constraints & Assumptions (约束假设)
7. Out of Scope (范围外)
8. Dependencies (依赖关系)
9. 全部章节

请选择要编辑的章节 (1-9): 4

⚠️ 注意: 此PRD已关联Epic "epic-blog-system"
修改Requirements可能影响现有任务分解。
编辑完成后建议运行: /pm:epic-sync blog-system

📝 正在编辑 Requirements 章节...
```

#### 预期输出
```
✅ PRD编辑完成: blog-system
📝 修改章节: Requirements
⏰ 更新时间: 2024-01-19 15:30:00
🔗 关联Epic: epic-blog-system (需要同步)

🔄 建议下一步:
/pm:prd-parse blog-system    # 重新生成技术方案
/pm:epic-sync blog-system    # 同步到GitHub
```

---

## 第三阶段：PRD转技术实现方案

### `/pm:prd-parse` - 转换PRD为技术Epic

**官方来源**: `.claude/commands/pm/prd-parse.md`

#### 命令语法
```bash
/pm:prd-parse <feature_name>
```

#### 前置条件
- PRD文件已存在且格式正确
- PRD的frontmatter包含必需字段

#### 功能说明
将产品需求文档转换为详细的技术实现Epic，包括架构决策、技术方法和任务分解预览。

#### 完整示例：解析博客系统PRD

```bash
# 1. 解析PRD
/pm:prd-parse blog-system

# 2. 系统会分析PRD并创建技术实现方案
```

**Epic文件结构**（基于官方模板）:
```yaml
---
name: blog-system
status: backlog
created: 2025-01-19T11:00:00Z
progress: 0%
prd: .claude/prds/blog-system.md
github: null  # 同步后更新
---

# Blog System - 技术实现Epic

## Overview（概述）
基于Python + React技术栈构建全功能个人博客平台，采用前后端分离架构，确保高性能和良好的用户体验。

## Architecture Decisions（架构决策）

### 后端技术栈
- **Web框架**: FastAPI（异步支持，自动API文档）
- **数据库**: PostgreSQL（关系型数据，支持全文搜索）
- **认证**: JWT + OAuth2（标准化，无状态）
- **缓存**: Redis（会话存储，页面缓存）

### 前端技术栈
- **框架**: React 18（组件化，生态成熟）
- **状态管理**: Zustand（轻量级，易于调试）
- **样式**: Tailwind CSS（快速开发，一致性）
- **富文本**: React-Quill（功能丰富，可扩展）

## Technical Approach（技术方法）

### 数据库设计
- Users (id, username, email, password_hash, role, created_at)
- Posts (id, title, content, slug, status, author_id, created_at, updated_at)
- Categories (id, name, slug, description)
- Tags (id, name, slug)
- Comments (id, post_id, author_id, content, parent_id, created_at)

### API设计
- GET  /api/posts          # 获取文章列表
- POST /api/posts          # 创建文章
- GET  /api/posts/{id}     # 获取单篇文章
- PUT  /api/posts/{id}     # 更新文章
- DELETE /api/posts/{id}   # 删除文章
- POST /api/auth/login     # 用户登录
- POST /api/auth/register  # 用户注册

## Task Breakdown Preview（任务分解预览）
### 数据库相关（2-3个任务）
- 设计数据库schema和迁移脚本
- 实现ORM模型和关系

### 后端API（3-4个任务）
- 用户认证和授权系统
- 文章管理API endpoints
- 评论系统API
- 搜索和过滤功能

### 前端界面（3-4个任务）
- 基础组件库和布局
- 文章展示和编辑界面
- 用户认证界面
- 管理后台界面
```

#### 输出文件
```
.claude/epics/blog-system/epic.md
```

---

## 第四阶段：任务分解和GitHub同步

### `/pm:epic-decompose` - 分解Epic为具体任务

**官方来源**: `.claude/commands/pm/epic-decompose.md`

#### 命令语法
```bash
/pm:epic-decompose <feature_name>
```

#### 功能说明
将Epic分解为具体的、可执行的任务。支持并行创建任务以提高效率。

#### 完整示例：分解博客系统Epic

```bash
# 1. 分解Epic
/pm:epic-decompose blog-system

# 系统会基于Epic内容创建多个任务文件
```

**任务文件示例**（`.claude/epics/blog-system/001.md`）:
```yaml
---
name: "数据库Schema设计和迁移脚本"
status: open
created: 2025-01-19T11:30:00Z
updated: 2025-01-19T11:30:00Z
github: null  # 同步后更新
depends_on: []
parallel: true
conflicts_with: []
---

# 任务001: 数据库Schema设计和迁移脚本

## Description（描述）
设计和实现博客系统的完整数据库schema，包括用户、文章、分类、标签和评论等核心表结构，并创建相应的迁移脚本。

## Acceptance Criteria（验收标准）
- [ ] 完成所有核心表的设计（Users, Posts, Categories, Tags, Comments）
- [ ] 创建Alembic迁移脚本
- [ ] 包含适当的索引和约束
- [ ] 通过数据库设计评审
- [ ] 迁移脚本可以成功执行

## Technical Details（技术细节）
### 表结构设计
- Users表：用户基本信息和认证
- Posts表：文章内容和元数据
- Categories表：文章分类
- Tags表：文章标签
- Comments表：评论系统

### 迁移脚本要求
- 使用Alembic进行版本控制
- 包含回滚脚本
- 添加必要的索引
- 设置外键约束

## Dependencies（依赖关系）
- 无前置依赖，这是基础任务

## Effort Estimate（工作量估计）
- **预估时间**: 4-6小时
- **复杂度**: 中等
- **风险等级**: 低
```

### `/pm:epic-sync` - 同步到GitHub

**官方来源**: `.claude/commands/pm/epic-sync.md`

#### 命令语法
```bash
/pm:epic-sync <feature_name>
```

#### 功能说明
将Epic和所有任务推送到GitHub作为Issues，建立父子关系，并创建工作树用于并行开发。

#### 同步过程详解

1. **创建Epic Issue**
```bash
# 在GitHub创建主Epic Issue
gh issue create --title "Epic: Blog System Implementation" \
  --body-file .claude/epics/blog-system/epic.md \
  --label "epic,epic:blog-system"
```

2. **创建任务Sub-Issues**
```bash
# 为每个任务创建子Issue
gh issue create --title "数据库Schema设计和迁移脚本" \
  --body-file .claude/epics/blog-system/001.md \
  --label "task,epic:blog-system"

# 如果安装了gh-sub-issue扩展，建立父子关系
gh sub-issue create <epic_issue_id> <task_issue_id>
```

3. **文件重命名**
```bash
# 原文件名 -> GitHub Issue ID
001.md -> 1234.md  # 假设Issue ID是1234
002.md -> 1235.md
```

4. **创建工作树**
```bash
# 在项目外创建独立工作目录
git worktree add ../epic-blog-system epic/blog-system
```

#### 输出结果
```
✓ Epic Issue created: #1230
✓ Task Issues created: #1231, #1232, #1233, #1234, #1235
✓ Files renamed to Issue IDs
✓ Worktree created: ../epic-blog-system
✓ Sync complete - ready for parallel development
```

### `/pm:epic-oneshot` - 一键分解并同步

**官方来源**: `.claude/commands/pm/epic-oneshot.md`

#### 命令语法
```bash
/pm:epic-oneshot <feature_name>
```

#### 功能说明
组合执行 `/pm:epic-decompose` 和 `/pm:epic-sync`，适合确信Epic已就绪的情况。

#### 完整示例
```bash
# 一键完成分解和同步
/pm:epic-oneshot blog-system

# 等价于：
# /pm:epic-decompose blog-system
# /pm:epic-sync blog-system
```

---

## 第五阶段：并行执行开发

### `/pm:issue-analyze` - 分析任务并行化策略

**官方来源**: `.claude/commands/pm/issue-analyze.md`

#### 命令语法
```bash
/pm:issue-analyze <issue_number>
```

#### 功能说明
分析单个Issue，识别可并行的工作流，最大化开发效率。

#### 完整示例：分析数据库任务

```bash
# 1. 分析任务
/pm:issue-analyze 1234

# 系统会创建分析文件
```

**分析文件示例**（`.claude/epics/blog-system/1234-analysis.md`）:
```yaml
---
issue: 1234
title: "数据库Schema设计和迁移脚本"
analyzed_at: 2025-01-19T12:00:00Z
parallel_streams: 3
estimated_time_parallel: "2-3 hours"
estimated_time_sequential: "6-8 hours"
---

# Issue #1234 并行化分析

## 识别的并行工作流

### 工作流1：Schema设计 (schema-design)
**文件范围**: `models/`, `migrations/schema/`
**工作内容**:
- 设计表结构
- 定义关系和约束
- 创建基础model类

**预估时间**: 2小时
**依赖**: 无
**冲突风险**: 无

### 工作流2：迁移脚本 (migration-scripts)
**文件范围**: `migrations/versions/`, `alembic.ini`
**工作内容**:
- 创建Alembic配置
- 编写迁移脚本
- 测试迁移和回滚

**预估时间**: 2小时
**依赖**: Schema设计完成
**冲突风险**: 低

### 工作流3：测试数据 (test-data)
**文件范围**: `tests/fixtures/`, `seeds/`
**工作内容**:
- 创建测试数据
- 编写数据fixtures
- 性能测试数据

**预估时间**: 1小时
**依赖**: 迁移脚本完成
**冲突风险**: 无

## 并行化策略
### 推荐执行顺序
1. **Phase 1** (并行): Schema设计
2. **Phase 2** (串行): 迁移脚本（依赖Schema）
3. **Phase 3** (并行): 测试数据

## 建议的代理分配
- **Agent 1**: 专注Schema设计和Model定义
- **Agent 2**: 专注迁移脚本和Alembic配置
- **Agent 3**: 专注测试数据和Fixtures
```

### `/pm:epic-start` - 启动Epic并行执行

**官方来源**: `.claude/commands/pm/epic-start.md`

#### 命令语法
```bash
/pm:epic-start <epic_name>
```

#### 功能说明
启动整个Epic的并行代理执行，自动分析所有就绪的Issues并启动相应的工作流。

#### 执行状态文件示例
```yaml
---
epic: blog-system
status: in_progress
started_at: 2025-01-19T12:30:00Z
branch: epic/blog-system
worktree: ../epic-blog-system
active_agents: 3
---

# Blog System Epic 执行状态

## 当前活跃代理
### Agent 1: Database Schema
- **Issue**: #1234
- **工作流**: schema-design
- **状态**: active
- **进度**: 60%
- **预计完成**: 13:30

### Agent 2: User Authentication
- **Issue**: #1235
- **工作流**: auth-backend
- **状态**: active
- **进度**: 30%
- **预计完成**: 14:00

### Agent 3: Frontend Components
- **Issue**: #1236
- **工作流**: ui-components
- **状态**: active
- **进度**: 45%
- **预计完成**: 13:45

## 统计信息
- **总任务数**: 8
- **进行中**: 3
- **等待中**: 2
- **已完成**: 0
- **整体进度**: 25%
```

### `/pm:issue-start` - 启动单个任务

**官方来源**: `.claude/commands/pm/issue-start.md`

#### 命令语法
```bash
/pm:issue-start <issue_number>
```

#### 功能说明
基于工作流分析启动单个Issue的并行代理。如果没有分析文件，会自动进行分析。

### `/pm:issue-sync` - 同步Issue进度到GitHub

**官方来源**: `.claude/commands/pm/issue-sync.md`

#### 命令语法
```bash
/pm:issue-sync <issue_number>
```

#### 功能说明
将本地开发进度推送到GitHub作为Issue评论，建立透明的审计跟踪。

#### 前置条件
- GitHub CLI已认证 (`gh auth status`)
- Issue存在且可访问
- 本地更新目录存在 (`.claude/epics/*/updates/<issue_number>/`)
- 远程仓库不能是CCPM模板仓库

#### 核心特性
- **增量同步检测**: 只同步自上次sync后的新内容，防止重复评论
- **进度追踪**: 自动计算完成百分比并更新frontmatter
- **审计跟踪**: 维护同步时间戳用于审计
- **评论大小管理**: 处理GitHub 65,536字符限制，支持分割评论
- **Epic进度计算**: 任务完成时自动重新计算Epic进度

#### 详细使用示例
```bash
# 同步Issue #1235的最新进度
/pm:issue-sync 1235

# 系统会自动：
# 1. 检测自上次同步后的新更新
# 2. 计算当前完成百分比
# 3. 格式化进度报告
# 4. 推送到GitHub作为评论
# 5. 更新本地同步时间戳
```

#### 预期输出
```
✅ Issue同步完成: #1235
📊 进度: 75% (3/4 验收标准完成)
💬 GitHub评论: 已添加进度更新
⏰ 同步时间: 2024-01-19 14:30:00
🔄 Epic进度: 重新计算中...
```

### `/pm:issue-show` - 显示Issue详细信息

**官方来源**: `.claude/commands/pm/issue-show.md`

#### 命令语法
```bash
/pm:issue-show <issue_number>
```

#### 功能说明
显示Issue和相关子Issue的详细信息，包括GitHub状态和本地文件映射。

#### 核心特性
- **综合信息展示**: GitHub Issue详情 + 本地文件映射
- **关系展示**: 父Epic、依赖关系、阻塞关系、子任务
- **进度跟踪**: 验收标准状态显示
- **快速操作**: 提供常用命令快捷方式
- **最近活动**: 显示评论和更新历史

#### 详细使用示例
```bash
# 查看Issue详细信息
/pm:issue-show 1235
```

#### 预期输出格式
```
🎫 Issue #1235: 用户认证系统实现
   状态: 🔄 进行中
   标签: enhancement, backend, epic:blog-system
   负责人: Agent-1
   创建时间: 2024-01-19 10:00:00
   更新时间: 2024-01-19 14:15:00

📝 描述: 实现完整的用户注册、登录和权限管理功能
📁 本地文件: .claude/epics/blog-system/1235.md
🔗 相关Issues:
   ├─ 依赖: #1234 (数据库Schema) ✅ 已完成
   └─ 阻塞: #1238 (管理界面) ⏳ 等待中

💬 最近活动:
   - 14:15: 进度更新 - JWT认证完成
   - 13:30: 代理启动 - 开始实施

✅ 验收标准: (3/4 完成)
   ✅ 用户注册API端点
   ✅ 密码加密存储
   ✅ JWT令牌生成
   ⏳ 权限中间件实现

🚀 快速操作:
   /pm:issue-sync 1235    # 同步进度
   /pm:issue-start 1238   # 启动依赖任务
```

---

## 第六阶段：状态跟踪和监控

### `/pm:status` - 整体项目状态

**官方来源**: `.claude/commands/pm/status.md`

#### 命令语法
```bash
/pm:status
```

#### 功能说明
显示所有项目的整体状态概览。

#### 示例输出
```
CCPM Project Status Overview
============================

📊 Active Epics: 2
🔄 In Progress Issues: 5
✅ Completed Today: 3
⏳ Blocked Issues: 1

## Epic: blog-system (Epic #1230)
Status: 🔄 In Progress (60% complete)
├── ✅ #1234: Database Schema (completed)
├── 🔄 #1235: User Authentication (75% - 30min remaining)
├── 🔄 #1236: Frontend Components (45% - 1hr remaining)
├── ⏳ #1237: API Endpoints (blocked - waiting for #1234)
└── 📋 #1238: Admin Interface (ready)

🎯 Recommended Next Actions:
1. Check progress on #1235 (User Authentication)
2. Prepare to start #1237 (API Endpoints)
3. Consider starting #1238 (Admin Interface) in parallel
```

### `/pm:epic-show` - 显示特定Epic详情

**官方来源**: `.claude/commands/pm/epic-show.md`

#### 命令语法
```bash
/pm:epic-show <epic_name>
```

#### 示例输出
```
Epic: blog-system
=================

📋 Basic Info:
- Name: blog-system
- Status: In Progress
- GitHub: https://github.com/user/repo/issues/1230
- Progress: 60% (3/5 tasks completed)
- Started: 2025-01-19 12:30
- Estimated Completion: 2025-01-20 16:00

📊 Task Breakdown:
┌─────────────────────────────────────┬──────────┬────────────┬─────────────┐
│ Task                                │ Status   │ Progress   │ Time Left   │
├─────────────────────────────────────┼──────────┼────────────┼─────────────┤
│ #1234: Database Schema              │ ✅ Done  │ 100%       │ -           │
│ #1235: User Authentication          │ 🔄 Active│ 75%        │ 30min       │
│ #1236: Frontend Components          │ 🔄 Active│ 45%        │ 1hr         │
│ #1237: API Endpoints                │ ⏳ Blocked│ 0%         │ Waiting     │
│ #1238: Admin Interface              │ 📋 Ready │ 0%         │ 2hrs        │
└─────────────────────────────────────┴──────────┴────────────┴─────────────┘

🚀 Active Agents:
- Agent 1: Working on User Authentication (#1235)
- Agent 2: Working on Frontend Components (#1236)

💡 Recommendations:
1. Focus resources on completing #1235 to unblock #1238
2. Consider starting #1237 as #1234 dependency is actually resolved
3. Review time estimates - some tasks consistently taking longer
```

### `/pm:next` - 智能下一步建议

**官方来源**: `.claude/commands/pm/next.md`

#### 命令语法
```bash
/pm:next
```

#### 功能说明
分析当前项目状态，提供智能的下一步行动建议。

#### 示例输出
```
🎯 Next Recommended Actions
===========================

## Immediate Actions (Next 1 hour)

### 1. 🔥 High Priority: Complete User Authentication
**Issue**: #1235 - User Authentication
**Reason**: Blocking other tasks (#1238)
**Action**: Check Agent 1 progress, provide assistance if needed
**Expected Impact**: Unblocks Admin Interface development

### 2. 🚀 Quick Win: Start API Endpoints
**Issue**: #1237 - API Endpoints
**Reason**: Dependency #1234 actually completed, but status not updated
**Action**: Run `/pm:issue-start 1237`
**Expected Impact**: Parallel progress while auth completes

## Resource Optimization
**Current Capacity**: 2/3 agents active (67% utilization)
**Recommendation**: Start #1237 to reach optimal 3/3 agent utilization
**Estimated Completion**: Tomorrow 16:00 → Tomorrow 14:30 (1.5hr savings)

🎯 **Suggested Next Command**: `/pm:issue-start 1237`
```

---

## 维护和同步命令

### `/pm:sync` - 双向同步

**官方来源**: `.claude/commands/pm/sync.md`

#### 命令语法
```bash
# 同步所有Epic
/pm:sync

# 同步特定Epic
/pm:sync <epic_name>
```

#### 功能说明
在本地文件和GitHub Issues之间进行完整的双向同步。

### `/pm:validate` - 验证系统状态

**官方来源**: `.claude/commands/pm/validate.md`

#### 命令语法
```bash
/pm:validate
```

#### 功能说明
检查CCPM系统的完整性和一致性。

#### 示例输出
```
CCPM System Validation
======================

✅ GitHub CLI: Installed and authenticated
✅ gh-sub-issue: Extension available
✅ Directory Structure: All required directories exist
✅ PRD Files: 2 valid PRDs found
✅ Epic Files: 2 epics, all valid
✅ Task Files: 12 tasks, all valid format

⚠️  Warnings:
- Epic 'blog-system' has 1 task with missing GitHub mapping
- 2 worktrees found but not referenced in active epics

❌ Errors:
- Task #1237: Invalid dependency reference (points to non-existent task)
- Epic 'old-project': Referenced GitHub issue not found

🔧 Suggested Fixes:
1. Run `/pm:sync blog-system` to fix GitHub mappings
2. Clean up orphaned worktrees with `/pm:clean`
3. Update dependency in task #1237 or create missing dependency task
```

### `/pm:clean` - 清理系统

**官方来源**: `.claude/commands/pm/clean.md`

#### 命令语法
```bash
/pm:clean
```

#### 功能说明
清理临时文件、无效状态和孤立的工作树。

---

## 实战完整示例

### 完整项目流程演示

让我们通过一个完整的博客系统项目演示整个CCPM工作流程：

```bash
# === 第1步：系统初始化 ===
/pm:init
# ✅ GitHub CLI安装并认证
# ✅ 目录结构创建完成

# === 第2步：创建PRD ===
/pm:prd-new blog-system
# 📝 交互式PRD创建会话
# ✅ 创建文件：.claude/prds/blog-system.md

# === 第3步：PRD转技术方案 ===
/pm:prd-parse blog-system
# 🔧 技术架构分析
# ✅ 创建文件：.claude/epics/blog-system/epic.md

# === 第4步：一键分解并同步 ===
/pm:epic-oneshot blog-system
# 📋 Epic分解为5个任务
# 🔗 同步到GitHub Issues
# ✅ 创建工作树：../epic-blog-system

# === 第5步：并行开发执行 ===
/pm:epic-start blog-system
# 🚀 启动3个并行代理
# 📊 创建执行状态跟踪

# === 第6步：监控和调整 ===
/pm:status
# 📊 查看整体进度

/pm:epic-show blog-system
# 🔍 查看详细状态

/pm:next
# 🎯 获取下一步建议

# === 第7步：完成和清理 ===
/pm:sync blog-system
# 🔄 最终状态同步

/pm:validate
# ✅ 验证系统完整性
```

---

## 命令速查表

### 工作流程命令
| 命令 | 功能 | 示例 |
|------|------|------|
| `/pm:init` | 初始化系统 | `/pm:init` |
| `/pm:prd-new` | 创建PRD | `/pm:prd-new blog-system` |
| `/pm:prd-list` | 列出所有PRD | `/pm:prd-list` |
| `/pm:prd-edit` | 编辑PRD | `/pm:prd-edit blog-system` |
| `/pm:prd-parse` | PRD转Epic | `/pm:prd-parse blog-system` |
| `/pm:epic-decompose` | 分解任务 | `/pm:epic-decompose blog-system` |
| `/pm:epic-sync` | 同步GitHub | `/pm:epic-sync blog-system` |
| `/pm:epic-oneshot` | 一键处理 | `/pm:epic-oneshot blog-system` |

### 执行命令
| 命令 | 功能 | 示例 |
|------|------|------|
| `/pm:issue-analyze` | 分析任务 | `/pm:issue-analyze 1234` |
| `/pm:epic-start` | 启动Epic并行执行 | `/pm:epic-start blog-system` |
| `/pm:issue-start` | 启动单个任务 | `/pm:issue-start 1234` |
| `/pm:issue-sync` | 同步Issue进度 | `/pm:issue-sync 1234` |
| `/pm:issue-show` | 显示Issue详情 | `/pm:issue-show 1234` |

### 状态命令
| 命令 | 功能 | 示例 |
|------|------|------|
| `/pm:status` | 整体状态 | `/pm:status` |
| `/pm:epic-show` | Epic详情 | `/pm:epic-show blog-system` |
| `/pm:next` | 下一步建议 | `/pm:next` |

### 维护和调试命令
| 命令 | 功能 | 示例 |
|------|------|------|
| `/pm:sync` | 双向同步 | `/pm:sync blog-system` |
| `/pm:validate` | 系统验证 | `/pm:validate` |
| `/pm:clean` | 清理系统 | `/pm:clean` |
| `/pm:test-reference-update` | 测试引用更新 | `/pm:test-reference-update` |
| `/pm:help` | 帮助信息 | `/pm:help` |

---

## 重要注意事项

### 命名规范
- **PRD和Epic名称**: 必须使用kebab-case（小写字母、数字、连字符）
- **分支命名**: 自动使用 `epic/<feature_name>` 格式
- **工作树**: 自动创建在 `../epic-<feature_name>`

### 依赖关系
- PRD必须在Epic创建前存在
- Epic必须在任务分解前存在
- 任务必须在GitHub同步前分解
- GitHub同步必须在并行执行前完成

### 文件结构
```
.claude/
├── prds/<feature>.md           # PRD文档
├── epics/<feature>/
│   ├── epic.md                 # Epic实现方案
│   ├── <issue_id>.md          # 任务文件
│   ├── <issue_id>-analysis.md # 任务分析
│   ├── execution-status.md    # 执行状态
│   └── updates/<issue_id>/    # 进度更新
│       └── stream-*.md        # 工作流进度
```

### 最佳实践
1. **PRD质量决定成败** - 投入充分时间完善PRD
2. **Epic目标10个以下任务** - 保持合理规模
3. **及时同步状态** - 定期运行 `/pm:sync`
4. **监控并行效率** - 使用 `/pm:status` 跟踪进度
5. **验证系统健康** - 定期运行 `/pm:validate`

---

## 高级功能补充

### Worktree管理 - 独立并行开发

#### Epic并行执行详解

**官方来源**: `.claude/commands/pm/epic-start.md`

CCPM的核心优势之一是支持在独立worktree中并行执行多个任务，避免代理间的上下文干扰。

##### Worktree创建和管理
```bash
# 启动Epic时自动创建worktree
/pm:epic-start blog-system

# Worktree位置: ../epic-blog-system
# 分支: epic/blog-system
# 独立工作目录，不影响主分支开发
```

##### 代理协调机制
- **文件级并行**: 不同代理处理不同文件，避免冲突
- **原子提交**: 每个代理频繁提交，格式`"Issue #1234: 具体更改"`
- **进度跟踪**: 实时更新到`.claude/epics/{epic}/updates/{issue}/stream-{X}.md`
- **依赖检查**: 自动检测任务完成并解锁依赖任务

##### 并行工作流示例
```
代理协调示例 - 博客系统开发:

Agent-1 (数据库专家):
  └─ Issue #1234: 数据库Schema
     ├─ Stream A: 设计表结构
     └─ Stream B: 编写迁移脚本

Agent-2 (后端专家):
  └─ Issue #1235: API端点
     ├─ Stream A: 用户认证API
     └─ Stream B: 文章管理API

Agent-3 (前端专家):
  └─ Issue #1236: UI组件
     ├─ Stream A: 基础组件库
     └─ Stream B: 页面布局

实时状态监控:
/pm:epic-show blog-system  # 查看整体进度
/pm:issue-show 1234        # 查看具体任务详情
```

### 配置和调试命令

#### `/pm:test-reference-update` - 引用更新测试

**官方来源**: `.claude/commands/pm/test-reference-update.md`

##### 功能说明
测试任务引用更新逻辑，确保Issue编号映射的正确性。

##### 测试流程
```bash
/pm:test-reference-update

测试场景:
- 任务001: 冲突 [002, 003] → Issue #1234
- 任务002: 依赖 001，冲突 003 → Issue #1235
- 任务003: 依赖 001, 002 → Issue #1236

验证项目:
✅ 依赖关系正确映射
✅ 冲突关系正确更新
✅ 循环依赖检测
✅ 引用完整性验证
```

#### 增强的系统维护命令

##### `/pm:validate` - 系统状态验证
```bash
/pm:validate

检查项目:
✅ GitHub CLI认证状态
✅ gh-sub-issue扩展可用性
✅ 目录结构完整性
✅ PRD文件格式验证
✅ Epic文件有效性
✅ 任务文件语法检查
✅ GitHub映射一致性

⚠️ 警告处理:
- 孤立worktree清理建议
- 未同步任务提醒
- 依赖关系验证

❌ 错误修复:
- 自动修复可修复的格式问题
- 提供手动修复指导
- 生成修复脚本
```

##### `/pm:sync` 增强功能
```bash
# 双向同步增强
/pm:sync [epic_name]

同步策略:
1. 从GitHub拉取最新状态
2. 检测本地和远程的冲突更改
3. 提供冲突解决选项
4. 应用用户选择的解决方案
5. 推送本地更改到GitHub
6. 更新时间戳和状态

冲突处理:
- local: 保留本地更改
- github: 使用GitHub状态
- merge: 交互式合并
```

### 专门代理系统

#### 四大核心代理类型

**官方来源**: 基于`.claude/agents/`目录分析

##### 1. file-analyzer (文件分析代理)
- **专长**: 日志分析、大文件摘要、错误诊断
- **使用场景**: 分析执行日志、提取关键信息
- **优势**: 减少上下文使用，提供精确摘要

##### 2. code-analyzer (代码分析代理)
- **专长**: 代码审查、漏洞检测、架构分析
- **使用场景**: 代码质量检查、逻辑跟踪
- **优势**: 深度代码理解，安全漏洞识别

##### 3. test-runner (测试执行代理)
- **专长**: 测试执行、结果分析、质量保证
- **使用场景**: 自动化测试、持续集成
- **优势**: 完整测试覆盖，详细错误报告

##### 4. parallel-worker (并行工作代理)
- **专长**: 多任务协调、并行执行管理
- **使用场景**: 大型Epic的并行开发
- **优势**: 避免上下文污染，提高执行效率

#### 代理调用最佳实践

```bash
# 分析复杂日志文件
使用 file-analyzer 代理处理大型日志

# 代码安全审查
使用 code-analyzer 代理检查潜在漏洞

# 执行完整测试套件
使用 test-runner 代理运行所有测试

# 启动并行开发
使用 parallel-worker 代理协调多任务
```

### 规则驱动机制

#### 九大核心规则文件

**官方来源**: `.claude/rules/`目录

1. **agent-coordination.md** - 代理协调规则
2. **time-handling.md** - 时间戳处理规则
3. **git-practices.md** - Git工作流规则
4. **frontmatter-rules.md** - 元数据格式规则
5. **epic-management.md** - Epic管理规则
6. **issue-tracking.md** - Issue跟踪规则
7. **testing-standards.md** - 测试标准规则
8. **documentation.md** - 文档维护规则
9. **security-practices.md** - 安全实践规则

#### 关键规则要点

##### 时间戳规则 (最高优先级)
- 所有时间戳必须使用真实当前时间
- 禁止使用示例或占位符时间
- 时间格式: ISO 8601 (2024-01-19T15:30:00Z)

##### 代理协调规则
- 频繁提交避免冲突
- 明确的提交信息格式
- 进度更新到指定目录
- 文件级别的并行控制

##### Frontmatter规则
- 严格的YAML格式要求
- 必需字段验证
- 时间戳自动更新
- 状态生命周期管理

### 性能优化建议

#### 并行化最佳实践
- **代理数量**: 建议同时运行3-5个代理
- **任务分解**: 每个Epic控制在8-12个任务
- **依赖管理**: 避免过度依赖，增加并行度
- **资源监控**: 定期检查系统资源使用

#### 存储优化
- **定期清理**: 清理完成的Epic工作目录
- **压缩历史**: 归档旧的PRD和Epic文件
- **缓存管理**: 合理使用GitHub API缓存

#### 网络优化
- **批量操作**: 批量创建和更新GitHub Issues
- **增量同步**: 只同步变更的内容
- **错误重试**: 网络错误的自动重试机制

### 企业级功能

#### 团队协作增强
- **权限控制**: 基于GitHub团队的权限管理
- **审批流程**: 关键操作的审批机制
- **通知系统**: 重要事件的自动通知

#### 集成能力
- **CI/CD集成**: 与Jenkins、GitHub Actions集成
- **监控集成**: 与Prometheus、Grafana集成
- **文档集成**: 与Confluence、Notion集成

#### 安全加强
- **访问审计**: 完整的操作审计日志
- **数据加密**: 敏感数据的加密存储
- **合规支持**: 符合SOC2、ISO27001等标准

---

**补充说明**: 本文档基于CCPM官方源码深度分析，涵盖了所有49个命令文件、14个执行脚本和9个核心规则。确保信息的完整性和准确性。

**基于官方源码验证，确保所有命令语法和功能描述准确无误。**
**参考文档**: [CCPM GitHub仓库](https://github.com/automazeio/ccpm) - 命令定义文件